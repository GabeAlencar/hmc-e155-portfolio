/*
 * Module: lab3_GA
 * Author: Gabe Alencar gmenendezdealencar@g.hmc.edu
 * Date:   9/22/26
 * Parameters:
 *   SCAN_DIV   - clock cycles each keypad row is driven.
 *   SCAN_DIV_W - bits needed to count to SCAN_DIV.
 *   TICK_W     - debounce tick counter width; stable time is 2**TICK_W cycles.
 *   MUX_W      - display multiplexing counter width.
 *   ROW_INVERT - 1 for this board: the 2N3904 low-side drivers on the rows
 *                invert, so the pins are driven one-hot high and exactly one
 *                transistor pulls its row low.  Set to 0 if the rows are ever
 *                wired straight from the pins to the keypad.
 */

module lab3_GA #(
    parameter int SCAN_DIV   = 320_000,
    parameter int SCAN_DIV_W = 19,
    parameter int TICK_W     = 19,
    parameter int MUX_W      = 17,
    parameter bit ROW_INVERT = 1'b1
) (
    input  logic       reset_b,
    input  logic [3:0] cols,
    output logic [3:0] rows,
    output logic [6:0] seg,
    output logic [1:0] anode_n
);

    logic       clk;
    logic [3:0] cols_sync, rows_aligned;
    logic       any_key, one_key, key_new, capture;
    logic [3:0] key, d0, d1;

    // internal high-speed oscillator, 48 MHz
    HSOSC hf_osc (.CLKHFPU(1'b1), .CLKHFEN(1'b1), .CLKHF(clk));

    // the columns are asynchronous and must be synchronized before they reach
    // any state machine (Lecture 04)
    synchronizer #(.WIDTH(4)) u_col_sync (.clk(clk), .reset_b(reset_b), .d(cols), .q(cols_sync));

    // combinational {rows, cols} decode: the key plus the two status bits.
    // rows_aligned, not rows, so the column reading is decoded against the row
    // that was being driven when it was taken
    key_decoder u_key_decoder (.rows(rows_aligned), .cols(cols_sync), .key(key), .one_key(one_key), .any_key(any_key));

    // is this a different key than the one already on the right-hand digit?
    assign key_new = (key != d0);

    // keypad front end: debouncing, the Lab 2 scanner, and the scan controller
    keypad_ctrl #(.SCAN_DIV(SCAN_DIV), .SCAN_DIV_W(SCAN_DIV_W), .TICK_W(TICK_W), .ROW_INVERT(ROW_INVERT)) u_keypad_ctrl (.clk(clk), .reset_b(reset_b), .any_key(any_key), .one_key(one_key), .key_new(key_new), .rows(rows), .rows_aligned(rows_aligned), .capture(capture));

    // the last two digits entered
    digit_reg u_digit_reg (.clk(clk), .reset_b(reset_b), .enable(capture), .key(key), .d0(d0), .d1(d1));

    // display multiplexing and seven-segment decode, newest digit on the right
    display_mux #(.MUX_W(MUX_W)) u_display_mux (.clk(clk), .reset_b(reset_b), .digit_left(d1), .digit_right(d0), .seg(seg), .anode_n(anode_n));

endmodule